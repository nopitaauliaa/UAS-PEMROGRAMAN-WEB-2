url 
pelanggan : http://localhost/jahit_pumira/pelanggan/katalog
admin : http://localhost/jahit_pumira/
